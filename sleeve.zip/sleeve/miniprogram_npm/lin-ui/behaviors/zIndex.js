// eslint-disable-next-line no-undef
export default Behavior({
  behaviors: [],
  properties: {
    zIndex:{
      type: Number,
      value: 777
    }
  }
});