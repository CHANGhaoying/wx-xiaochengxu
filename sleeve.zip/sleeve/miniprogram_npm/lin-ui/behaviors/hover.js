// eslint-disable-next-line no-undef
export default Behavior({
  behaviors: [],
  properties: {
    isHover:{
      type: Boolean,
      value: true
    }
  }
});